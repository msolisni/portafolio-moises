"use client";

import { useEffect, useState } from "react";
import { projects } from "@/data/projects";

const links = {
  linkedin: process.env.NEXT_PUBLIC_LINKEDIN_URL || "#contacto",
  github: process.env.NEXT_PUBLIC_GITHUB_URL || "#contacto",
  email: process.env.NEXT_PUBLIC_EMAIL || "",
};

const skills = [
  ["Desarrollo", "C#, .NET, ASP.NET Core, Python"],
  ["Datos", "SQL Server, PostgreSQL, SQLite, ETL"],
  ["Automatización", "n8n, APIs, Docker"],
  ["Inteligencia artificial", "RAG, embeddings, pgvector, MCP"],
];

export default function Home() {
  const [dark, setDark] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const saved = window.localStorage.getItem("portfolio-theme");
    const isDark = saved ? saved === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  function toggleTheme() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    window.localStorage.setItem("portfolio-theme", next ? "dark" : "light");
  }

  const navItems = [
    ["Inicio", "#inicio"], ["Sobre mí", "#sobre-mi"], ["Proyectos", "#proyectos"], ["Habilidades", "#habilidades"], ["Contacto", "#contacto"],
  ];

  return (
    <main>
      <header className="sticky top-0 z-30 border-b border-[var(--line)] bg-[color:var(--background)]/85 backdrop-blur-xl">
        <div className="shell flex h-16 items-center justify-between">
          <a href="#inicio" className="font-extrabold tracking-tight">MAS<span className="text-[var(--accent)]">.</span></a>
          <nav className="desktop-nav flex items-center gap-6" aria-label="Navegación principal">
            {navItems.map(([label, href]) => <a key={href} href={href} className="nav-link">{label}</a>)}
          </nav>
          <div className="flex items-center gap-2">
            <button className="button button-secondary !px-3 !py-2" onClick={toggleTheme} aria-label="Cambiar tema">{dark ? "☀" : "◐"}</button>
            <button className="button button-secondary !px-3 !py-2 md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-label="Abrir menú">☰</button>
          </div>
        </div>
        {menuOpen && <nav className="shell flex flex-col gap-3 border-t border-[var(--line)] py-4 md:hidden">{navItems.map(([label, href]) => <a onClick={() => setMenuOpen(false)} key={href} href={href} className="nav-link">{label}</a>)}</nav>}
      </header>

      <section id="inicio" className="relative overflow-hidden">
        <div className="absolute -right-32 top-6 h-96 w-96 rounded-full bg-[var(--glow)] blur-3xl" />
        <div className="shell relative grid min-h-[calc(100vh-4rem)] items-center gap-12 py-24 lg:grid-cols-[1.25fr_.75fr]">
          <div>
            <p className="eyebrow">Ingeniero en Sistemas de Información</p>
            <h1 className="mt-5 max-w-3xl text-5xl font-extrabold leading-[.98] tracking-[-.055em] sm:text-7xl">Construyo software y soluciones de datos que resuelven problemas reales.</h1>
            <p className="mt-7 max-w-2xl text-lg leading-8 text-[var(--muted)]">Moisés Asbel Solis combina desarrollo de software, bases de datos, automatización e inteligencia artificial para crear soluciones claras, mantenibles y orientadas a resultados.</p>
            <div className="mt-9 flex flex-wrap gap-3">
              <a href="#proyectos" className="button button-primary">Ver proyectos <span>→</span></a>
              <a href="/cv/Moises-Asbel-Solis-CV.pdf" className="button button-secondary" target="_blank">Descargar CV <span>↓</span></a>
            </div>
            <div className="mt-9 flex flex-wrap gap-5 text-sm font-semibold text-[var(--muted)]">
              <a className="hover:text-[var(--accent)]" href={links.linkedin} target={links.linkedin === "#contacto" ? undefined : "_blank"}>LinkedIn ↗</a>
              <a className="hover:text-[var(--accent)]" href={links.github} target={links.github === "#contacto" ? undefined : "_blank"}>GitHub ↗</a>
            </div>
          </div>
          <div className="card relative overflow-hidden p-7 shadow-2xl shadow-indigo-950/10">
            <div className="absolute right-0 top-0 h-36 w-36 rounded-bl-full bg-[var(--glow)]" />
            <p className="eyebrow relative">Enfoque profesional</p>
            <div className="relative mt-8 space-y-5">
              {["Aplicaciones web robustas", "Datos conectados y confiables", "Automatización de procesos", "IA aplicada con criterio"].map((item, i) => <div key={item} className="flex items-center gap-4"><span className="grid h-8 w-8 place-items-center rounded-full bg-[var(--glow)] text-sm font-bold text-[var(--accent)]">0{i + 1}</span><span className="font-bold">{item}</span></div>)}
            </div>
            <div className="relative mt-9 border-t border-[var(--line)] pt-5 text-sm leading-6 text-[var(--muted)]">Disponible para construir productos, automatizar flujos y transformar información en herramientas útiles.</div>
          </div>
        </div>
      </section>

      <section id="sobre-mi" className="section border-y border-[var(--line)] bg-[var(--surface)]">
        <div className="shell grid gap-10 lg:grid-cols-[.75fr_1.25fr] lg:gap-20">
          <div><p className="eyebrow">Sobre mí</p><h2 className="section-title">Tecnología con propósito.</h2></div>
          <div><p className="section-copy !mt-0">Soy Moisés Asbel Solis, Ingeniero en Sistemas de Información. Me interesa diseñar soluciones que conecten una buena experiencia de uso con una arquitectura responsable: desde aplicaciones .NET hasta procesos de datos y asistentes basados en recuperación de información.</p><p className="section-copy">Este portafolio prioriza lo que puede compartirse públicamente. Para proteger el trabajo propietario, los casos de estudio muestran el contexto, las decisiones y la arquitectura a alto nivel, sin publicar secretos ni código privado.</p></div>
        </div>
      </section>

      <section id="proyectos" className="section">
        <div className="shell"><p className="eyebrow">Proyectos seleccionados</p><h2 className="section-title">Trabajo que explica el porqué, no solo el resultado.</h2><p className="section-copy">Cada ficha está preparada para crecer con capturas, resultados verificables y enlaces públicos cuando corresponda.</p>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">{projects.map((project, index) => <article key={project.title} className="card overflow-hidden transition-transform duration-300 hover:-translate-y-1">
            <div className="project-visual relative p-5"><span className="rounded-full border border-[var(--accent)]/30 bg-[var(--surface-solid)] px-3 py-1 text-xs font-bold text-[var(--accent)]">0{index + 1}</span><div className="absolute bottom-5 text-sm font-semibold text-[var(--muted)]">{project.imageLabel}</div></div>
            <div className="p-6"><div className="flex items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-wider text-[var(--accent)]">{project.category}</p><h3 className="mt-2 text-xl font-extrabold">{project.title}</h3></div><span className="shrink-0 rounded-full border border-[var(--line)] px-2 py-1 text-[.66rem] font-bold text-[var(--muted)]">{project.visibility}</span></div>
              <p className="mt-4 text-sm leading-6 text-[var(--muted)]">{project.description}</p>
              <div className="mt-5"><p className="mb-2 text-xs font-bold uppercase tracking-wider text-[var(--muted)]">Arquitectura resumida</p><div className="flex flex-wrap gap-2">{project.architecture.map((item) => <span className="architecture-step" key={item}>{item}</span>)}</div></div>
              <div className="mt-5 flex flex-wrap gap-2">{project.technologies.map((tech) => <span key={tech} className="tag">{tech}</span>)}</div>
              {(project.demoUrl || project.githubUrl) && <div className="mt-6 flex gap-4 text-sm font-bold text-[var(--accent)]">{project.demoUrl && <a href={project.demoUrl}>Demo ↗</a>}{project.githubUrl && <a href={project.githubUrl}>GitHub ↗</a>}</div>}
            </div></article>)}</div>
        </div>
      </section>

      <section id="habilidades" className="section border-y border-[var(--line)] bg-[var(--surface)]"><div className="shell"><p className="eyebrow">Habilidades</p><h2 className="section-title">Un perfil que conecta producto, datos e infraestructura.</h2><div className="mt-12 grid gap-4 md:grid-cols-2">{skills.map(([area, tech]) => <div className="card p-6" key={area}><h3 className="font-extrabold">{area}</h3><p className="mt-3 leading-7 text-[var(--muted)]">{tech}</p></div>)}</div></div></section>

      <section id="cv" className="section"><div className="shell"><div className="card grid gap-8 bg-[var(--ink)] p-8 text-[var(--background)] md:grid-cols-[1fr_auto] md:items-center md:p-12"><div><p className="text-xs font-bold uppercase tracking-[.13em] text-indigo-300">Currículum</p><h2 className="mt-3 text-3xl font-extrabold tracking-tight">¿Quieres conocer mi experiencia en detalle?</h2><p className="mt-3 max-w-xl leading-7 opacity-75">Añade el PDF a <code className="rounded bg-white/10 px-1">public/cv/Moises-Asbel-Solis-CV.pdf</code> para activar la descarga.</p></div><a href="/cv/Moises-Asbel-Solis-CV.pdf" target="_blank" className="button bg-white text-slate-900">Ver CV <span>→</span></a></div></div></section>

      <section id="contacto" className="section border-t border-[var(--line)]"><div className="shell text-center"><p className="eyebrow">Contacto</p><h2 className="section-title mx-auto max-w-3xl">Conversemos sobre el próximo reto.</h2><p className="section-copy mx-auto">Para oportunidades profesionales, colaboraciones o una conversación técnica, puedes escribirme o encontrarme en mis perfiles.</p><div className="mt-8 flex flex-wrap justify-center gap-3">{links.email ? <a href={`mailto:${links.email}`} className="button button-primary">Escribirme <span>→</span></a> : <a href="mailto:tu-correo@ejemplo.com" className="button button-primary">Añadir correo <span>→</span></a>}<a href={links.linkedin} className="button button-secondary" target={links.linkedin === "#contacto" ? undefined : "_blank"}>LinkedIn ↗</a><a href={links.github} className="button button-secondary" target={links.github === "#contacto" ? undefined : "_blank"}>GitHub ↗</a></div></div></section>

      <footer className="border-t border-[var(--line)] py-7"><div className="shell flex flex-col justify-between gap-2 text-sm text-[var(--muted)] sm:flex-row"><span>© {new Date().getFullYear()} Moisés Asbel Solis.</span><span>Diseñado para comunicar trabajo, sin exponer información sensible.</span></div></footer>
    </main>
  );
}
